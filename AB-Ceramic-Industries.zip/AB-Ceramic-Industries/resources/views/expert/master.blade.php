@include('expert.head')

        @yield('content')

    <div class="modal fade" id="darkmodal">
      <div class="modal-dialog modal-lg">
        <div class="modal-content border-dark"></div>
      </div>
    </div>

@include('expert.footer')