@extends('expert.master')

@section('title', 'Backup - '.$settingsinfo->company_name.' - '.$settingsinfo->soft_name.'')

@section('content')

@include('expert.sidebar')

@include('expert.topbar')

@if($user_role_per->admin == 1)

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="card bg-dark">
      		<div class="card-header border-0 bg-transparent text-white">
                <i class="fa fa-user-circle"></i><span> Backup Manage</span>
            </div>

            <div class="card">
            <div class="card-header"><div style="display:inline-block; padding-top:5px;"><i class="fa fa-table"></i> Backup List </div> 

            <a href="{{ url('admin/backup/create') }}" class="btn btn-dark btn-sm waves-effect waves-light pull-right"> <i class="fa fa-plus"></i> <span>Create New Backup</span>
            </a>

          </div>

          
            
            <div class="card-body">

              <?php if (session('message')): ?>
                <div class="alert alert-{{session('class')}} alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert">×</button>
                  <div class="alert-icon contrast-alert"><i class="icon-close"></i></div>
                  <div class="alert-message"><span>{{session('message')}}</span></div>
                </div>
              <?php endif; ?>

              <div class="table-responsive">
                
                @if (count($backups))

                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th style="width: 5%; text-align: center;">SN</th>
                        <th style="width: 65%; text-align: left;">File</th>
                        <th style="width: 20%; text-align: center;">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @php $i=1; @endphp
                    @foreach($backups as $backup)
                        <tr>
                            <td style="width: 5%; text-align: center;">{{ $i++ }}</td>
                            <td style="width: 65%; text-align: left;">{{ $backup['file_name'] }}</td>
                           
                            <td style="width: 20%; text-align: center;">
                                <a class="btn btn-xs btn-success"
                                   href="{{ url('admin/backup/backup-download/'.$backup['file_name']) }}">
                                   <i class="fa fa-cloud-download"></i> 
                                   
                                   Download
                                </a>

                                <a class="btn btn-xs btn-danger" data-button-type="delete"
                                   href="{{ url('admin/backup/delete/'.$backup['file_name']) }}">
                                   <i class="fa fa-trash-o"></i>
                                    Delete
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @else
                <div class="well">
                    <h4>There are no backups</h4>
                </div>
            @endif

            </div>
            </div>
          </div>
               
          </div>
        </div>
      </div><!--End Row-->
	  
       <!--End Dashboard Content-->

    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   
   @endif

  @include('expert.copyright')

  @endsection

  @section('js')
    <script>
    $(document).ready(function() {
        dataTableLoad({
        });
    });
    </script>
  @endsection