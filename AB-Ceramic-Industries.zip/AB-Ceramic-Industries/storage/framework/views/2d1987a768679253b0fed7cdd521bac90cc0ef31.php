<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © <?php echo e(date('Y')); ?> <?php echo e($settingsinfo->company_name); ?> (All Right Reserved).
        </div>
      </div>
    </footer>
	<!--End footer-->
   
  </div><!--End wrapper--><?php /**PATH F:\Xampp\htdocs\HOSPITAL-MANAGEMENT-SYSTEM\resources\views/expert/copyright.blade.php ENDPATH**/ ?>