<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © <?php echo e(date('Y')); ?> <?php echo e($settingsinfo->company_name); ?> (All Right Reserved).
        </div>
      </div>
    </footer>
	<!--End footer-->
   
  </div><!--End wrapper--><?php /**PATH /home/modernhospital/public_html/resources/views/expert/copyright.blade.php ENDPATH**/ ?>