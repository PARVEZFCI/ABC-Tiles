<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class AisSubsidiaryCalculation extends Model
{
    public $timestamps = false;
    protected $table = "ais_subsidiary_calculation";
    protected $guarded = ['id'];

    
}
